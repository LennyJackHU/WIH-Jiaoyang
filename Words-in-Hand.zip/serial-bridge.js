// Words in Hand · resilient Web Serial bridge (Chrome/Edge, localhost/HTTPS)
export class WIHSerialBridge {
  constructor({ onWord, onStatus = () => {} }) {
    this.onWord = onWord;
    this.onStatus = onStatus;
    this.port = null;
    this.reader = null;
    this.running = false;
    this.busy = false;
    this.loopPromise = null;
    this.buffer = '';
    this.lastSeq = null;
    this.decoder = new TextDecoder();
    this.status = '未连接';
  }
  setStatus(value) { this.status = value; this.onStatus(value); }
  async connect() {
    if (this.busy || this.running) return;
    if (!('serial' in navigator)) throw new Error('请使用 Chrome/Edge，并通过 localhost 或 HTTPS 打开网页');
    this.busy = true;
    this.setStatus('正在连接…');
    try {
      // Reuse the same authorized port after a temporary interruption.
      if (!this.port) this.port = await navigator.serial.requestPort();
      if (!this.port.readable && !this.port.writable) {
        await this.port.open({ baudRate: 115200 });
      }
      // Avoid asserting DTR/RTS. Some ESP32 UART boards reset on control-line changes.
      try { await this.port.setSignals({ dataTerminalReady: false, requestToSend: false }); }
      catch (e) { console.debug('无法设置串口控制信号', e); }
      this.buffer = '';
      this.decoder = new TextDecoder();
      this.running = true;
      this.setStatus('已连接');
      this.loopPromise = this.readLoop();
    } catch (err) {
      this.running = false;
      this.setStatus('连接失败：' + err.message);
      throw err;
    } finally { this.busy = false; }
  }
  async readLoop() {
    try {
      while (this.running && this.port?.readable) {
        const readable = this.port.readable;
        this.reader = readable.getReader();
        try {
          while (this.running) {
            const { value, done } = await this.reader.read();
            if (done) break;
            this.buffer += this.decoder.decode(value, { stream: true });
            let idx;
            while ((idx = this.buffer.indexOf('\n')) !== -1) {
              const line = this.buffer.slice(0, idx).trim();
              this.buffer = this.buffer.slice(idx + 1);
              if (!line.startsWith('WIH:')) continue;
              try {
                const msg = JSON.parse(line.slice(4));
                if (msg.type !== 'word_confirmed' || typeof msg.word !== 'string') continue;
                if (msg.seq != null && msg.seq === this.lastSeq) continue;
                if (msg.seq != null) this.lastSeq = msg.seq;
                this.onWord(msg.word, msg);
              } catch (e) { console.warn('忽略无效词块数据', e); }
            }
            if (this.buffer.length > 8192) this.buffer = this.buffer.slice(-4096);
          }
        } finally {
          this.reader?.releaseLock();
          this.reader = null;
        }
        // If stream ended but port still exists, avoid a tight infinite loop.
        if (this.running && this.port?.readable === readable) break;
      }
    } catch (err) {
      if (this.running) {
        console.error('串口读取中断', err);
        this.setStatus('连接中断：' + err.message);
      }
    } finally {
      this.running = false;
      // Close the underlying port before claiming it is disconnected.
      if (this.port) {
        try { if (this.port.readable || this.port.writable) await this.port.close(); }
        catch (err) { console.warn('关闭串口失败', err); }
      }
      this.setStatus('未连接');
    }
  }
  async disconnect() {
    if (this.busy) return;
    this.busy = true;
    try {
      this.running = false;
      if (this.reader) { try { await this.reader.cancel(); } catch (e) {} }
      if (this.loopPromise) await this.loopPromise;
      if (this.port && (this.port.readable || this.port.writable)) {
        await this.port.close();
      }
      this.setStatus('未连接');
    } finally { this.busy = false; }
  }
}
